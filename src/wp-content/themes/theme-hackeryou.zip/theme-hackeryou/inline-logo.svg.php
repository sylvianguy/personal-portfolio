<svg class"tri" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
        viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
        <path d="M60.518,53.177L38.966,18.397l-4.62,7.46l-9.313-15.034L3.825,45.052l-0.342,0.552h18.628l-4.692,7.573H60.518z
        M19.577,51.978l19.389-31.301l19.394,31.301H19.577z M5.64,44.403l19.393-31.3l8.607,13.894L22.857,44.403H5.64z"/>
      </svg>