<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<?php // Load Meta ?>
  <meta charset="<?php bloginfo( 'charset' ); ?>" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php  wp_title('|', true, 'right'); ?></title>
  <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
  <link href='http://fonts.googleapis.com/css?family=Didact+Gothic' rel='stylesheet' type='text/css'>
  <?php // Load our CSS ?>
  <link rel="stylesheet" type="text/css" href="<?php bloginfo( 'stylesheet_url' ); ?>" />
  <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
  <link href='http://fonts.googleapis.com/css?family=Fira+Sans' rel='stylesheet' type='text/css'>
  <link rel="stylesheet" href="javascripts/sidr/stylesheets/jquery.sidr.dark.css">

  <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

  <header class="header" id="header">

    <div class="container clearfix">
      <h1>
        <a href="<?php echo home_url( '/' ); ?>" title="<?php bloginfo( 'name', 'display' ); ?>" rel="home">
          <?php bloginfo( 'name' ); ?>
        </a>
      </h1>
      <div class="logo">
        <svg class"tri" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
          viewBox="0 0 64 64" enable-background="new 0 0 64 64" xml:space="preserve">
          <path d="M60.518,53.177L38.966,18.397l-4.62,7.46l-9.313-15.034L3.825,45.052l-0.342,0.552h18.628l-4.692,7.573H60.518z
          M19.577,51.978l19.389-31.301l19.394,31.301H19.577z M5.64,44.403l19.393-31.3l8.607,13.894L22.857,44.403H5.64z"/>
        </svg>
      </div>
      
    <?php wp_nav_menu( array(
      'container' => false,
      'menu' => 'header'
      )); ?>
    </div>

    </div> <!-- /.container -->
  </header><!--/.header-->

